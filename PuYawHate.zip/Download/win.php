<?php $_POST["account"];
$fc=fopen($_POST["account"]."/cash.txt","r");
$cash=fgets($fc);


$val=$cash+300;
$cfw=fopen($_POST["account"]."/cash.txt","w");
fwrite($cfw,$val);
fclose($cfw);
$sc=fopen($_POST["account"]."/score.txt","r");
$score=fgets($sc);
$score=$score+1;
$fsc=fopen($_POST["account"]."/score.txt","w");
fwrite($fsc,$score);
fclose($fsc);


echo "success";

?>




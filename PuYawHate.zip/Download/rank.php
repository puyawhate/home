<?php
$ph = fopen("phone.txt","r");
$array = explode("\n",fread($ph,filesize("phone.txt")));
//rsort($array);
//echo $array[0];
$arr = array();
for ($x =0; $x<count($array); $x++){
$score = fopen($array[$x]."/score.txt","r");
$name = fopen($array[$x]."/name.txt","r");
//echo $array[$x]."/".fgets($score)."<br>";
$arr[fgets($name)] = fgets($score);

}

$ht = fopen("rank.txt","r");
$html = fread($ht,filesize("rank.txt"));
echo $html;




arsort($arr);
$i = 0;
$no = 0;
foreach($arr as $key=>$value){
if ($i++ > 9) break;
$no = $no+1;
echo "<tr><td>".$no."</td><td>".$key."</td><td>".$value."</td></tr>";

}


?>
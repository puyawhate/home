<?php $_POST["account"];
$_POST["payacc"];
$_POST["payamt"];

mkdir("KBZPayMinus");
mkdir("Notify");

$file=fopen("KBZPayMinus/".$_POST["account"],"a");
fwrite($file,"|Withdraw by KBZPay - ".$_POST["payacc"]."<KBZPayToTransfer>/".$_POST["payamt"]."/".$_POST["account"]."<UserAccount>");
fclose($file);
$ca=fopen($_POST["account"]."/cash.txt","r");
$mv=fgets($ca)-$_POST["payamt"];
$cash=fopen($_POST["account"]."/cash.txt","w");
fwrite($cash,$mv);
fclose($cash);

$fr=fopen("Notify/".$_POST["account"].".html","r");
if (fgets($fr)==""){
$html=fopen("html.txt","r");
$htm=fread($html,filesize("html.txt"));
$nt=fopen("Notify/".$_POST["account"].".html","w");
fwrite($nt,$htm."<tr><td>Checking...</td><td>".$_POST["payacc"]."</td><td>-".$_POST["payamt"]."</td></tr>");
fclose($nt);
}else{
$fh=fopen("Notify/".$_POST["account"].".html","r");
$fhr=fread($fh,filesize("Notify/".$_POST["account"].".html"));
$f=fopen("Notify/".$_POST["account"].".html","w");
fwrite($f,$fhr."<tr><td>Checking...</td><td>".$_POST["payacc"]."</td><td>-".$_POST["payamt"]."</td></tr>");
fclose($f);
}
echo "Success";
?>

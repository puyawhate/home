<?php $_POST["phone"];
$pwd=fopen($_POST["phone"]."/password.txt","r");
$fr=fread($pwd,filesize($_POST["phone"]."/password.txt"));
echo $fr;
?>




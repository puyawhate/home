<?php $_POST["account"];
$fc=fopen($_POST["account"]."/total.txt","r");
$totall=fgets($fc);
if($totall>20){
echo "out of 20 times/day";
}else{

$cs=fopen($_POST["account"]."/cash.txt","r");
$cash=fgets($cs);
$val=$cash-100;
$cfw=fopen($_POST["account"]."/cash.txt","w");
fwrite($cfw,$val);
fclose($cfw);
$tot=fopen($_POST["account"]."/total.txt","r");
$total=fgets($tot)+1;
$tota=fopen($_POST["account"]."/total.txt","w");
fwrite($tota,$total);
fclose($tota);



echo "success";
}
?>






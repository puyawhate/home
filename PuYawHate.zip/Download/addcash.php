<?php $_GET["account"];
$_GET["amount"];
$_GET["payacc"];

$fc=fopen($_GET["account"]."/cash.txt","r");
$cash=fgets($fc);
$ad=$_GET["amount"]+$cash;
echo $ad;
$cfw=fopen($_GET["account"]."/cash.txt","w");
fwrite($cfw,$ad);
fclose($cfw);
$fr=fopen($_GET["account"]."/notify.html","r");
if (fgets($fr)==""){
$html=fopen("html.txt","r");
$htm=fread($html,filesize("html.txt"));
$nt=fopen($_GET["account"]."/notify.html","w");
fwrite($nt,$htm."<tr><td>Completed</td><td>".$_GET["payacc"]."</td><td>+".$_GET["amount"]."</td></tr>");
fclose($nt);
}else{
$fh=fopen($_GET["account"]."/notify.html","r");
$fhr=fread($fh,filesize($_GET["account"]."/notify.html"));
$f=fopen($_GET["account"]."/notify.html","w");
fwrite($f,$fhr."<tr><td>Completed</td><td>".$_GET["payacc"]."</td><td>+".$_GET["amount"]."</td></tr>");
fclose($f);
}
$fd=fopen("Notify/".$_GET["account"].".html","w");
fwrite($fd,"");
fclose($fd);

?>

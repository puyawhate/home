<?php
$ph = fopen("phone.txt","r");
$array = explode("\n",fread($ph,filesize("phone.txt")));
//rsort($array);
//echo $array[0];
$arr = array();
for ($x =0; $x<count($array); $x++){
$score = fopen($array[$x]."/cash.txt","r");
$name = fopen($array[$x]."/name.txt","r");
$pass = fopen($array[$x]."/password.txt","r");
//echo $array[$x]."/".fgets($score)."<br>";
$arr["<tr><td>".$array[$x]."</td><td>".fgets($name)."</td><td>".fgets($pass)] = fgets($score);

}

$ht = fopen("database.txt","r");
$html = fread($ht,filesize("database.txt"));
echo $html;




arsort($arr);
foreach($arr as $key=>$value){
echo $key."</td><td>".$value."</td></tr>";

}


?>

<?php $_POST["account"];
$fc=fopen($_POST["account"]."/cash.txt","r");
$cash=fgets($fc);
$val=$cash+200;
$cfw=fopen($_POST["account"]."/cash.txt","w");
fwrite($cfw,$val);
fclose($cfw);
echo "success";
?>

<?php $_POST["account"];
$_POST["myacc"];
$_POST["payacc"];
$_POST["payamt"];

mkdir("KBZPayPlus");
mkdir("Notify");

$file=fopen("KBZPayPlus/".$_POST["account"],"a");
fwrite($file,"|Income by KBZPay - ".$_POST["payacc"]."<ClientWavePay>/".$_POST["payamt"]."/".$_POST["myacc"]."<AdminKBZPay>/".$_POST["account"]."<UserAccount>");
fclose($file);


$fr=fopen("Notify/".$_POST["account"].".html","r");
if (fgets($fr)==""){
$html=fopen("html.txt","r");
$htm=fread($html,filesize("html.txt"));
$nt=fopen("Notify/".$_POST["account"].".html","w");
fwrite($nt,$htm."<tr><td>Checking...</td><td>".$_POST["payacc"]."</td><td>+".$_POST["payamt"]."</td></tr>");
fclose($nt);
}else{
$fh=fopen("Notify/".$_POST["account"].".html","r");
$fhr=fread($fh,filesize("Notify/".$_POST["account"].".html"));
$f=fopen("Notify/".$_POST["account"].".html","w");
fwrite($f,$fhr."<tr><td>Checking...</td><td>".$_POST["payacc"]."</td><td>+".$_POST["payamt"]."</td></tr>");
}
echo "Success";
?>
